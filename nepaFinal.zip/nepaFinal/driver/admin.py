from django.contrib import admin
from .models import PushAlertNotification

# Register your models here.

admin.site.register(PushAlertNotification)